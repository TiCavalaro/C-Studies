﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ConsoleAppAula16
{
    internal class Pessoa
    {
        ////public string nome;
        ////public int idade;
        //public String marca,modelo;
        //public int ano;

        //public Pessoa()
        //{

        //}


        //public Pessoa(String marca, string modelo, int ano)
        //{
        //    this.marca = marca;
        //    this.modelo = modelo;

        //}


        //public void exibeDados()
        //{
        //    Console.WriteLine("Marca " + this.marca);
        //    Console.WriteLine("Modelo " + this.modelo);
        //    Console.WriteLine("Ano " + this.ano);
        //}
    }
}
