﻿namespace ConsoleAppAula16
{
    internal class Program
    {
        static void Main(string[] args)
        {
            //Console.WriteLine("Orimeiro programa OO Atos!");
            //Pessoa p = new Pessoa();
            //Carro c = new Carro();
            //Carro c2 = new Carro();
            //Carro c3 = new Carro();


            //Console.WriteLine("Digite o nome da pessoa");
            //p.nome = Console.ReadLine();
            //Console.WriteLine("Digite a idade da pessoa");
            //p.idade = int.Parse(Console.ReadLine());

            //Console.WriteLine("A pessoa instanciada e : " + p.nome);
            //Console.WriteLine("E tem " + p.idade + " anos");

            //p.exibeDados();

            //Carro c2 = new Carro("Snow","Focus", 56);
            //c2.exibeDados();





            //Console.WriteLine("Digite a marca do carro");
            //c.marca = Console.ReadLine();
            //Console.WriteLine("Digite o modelo do carro");
            //c.modelo = Console.ReadLine();
            //Console.WriteLine("Digite o ano de fabricacao do carro");
            //c.ano = int.Parse(Console.ReadLine());

            //c.exibeDados();

            //Console.WriteLine("Digite a marca do carro");
            //c2.marca = Console.ReadLine();
            //Console.WriteLine("Digite o modelo do carro");
            //c2.modelo = Console.ReadLine();
            //Console.WriteLine("Digite o ano de fabricacao do carro");
            //c2.ano = int.Parse(Console.ReadLine());

            //Console.WriteLine("Digite a marca do carro");
            //mar = Console.ReadLine();
            //Console.WriteLine("Digite o modelo do carro");
            //mod = Console.ReadLine();
            //Console.WriteLine("Digite o ano de fabricacao do carro");
            //ano = int.Parse(Console.ReadLine());


            //c3.defineDados(mar,mo,ano);
            //c3.exibeDados();




            //Console.WriteLine("Primeiro programa OO Atos!");
            //Notebook n = new Notebook();
            //Notebook n2;


            //Console.WriteLine("Digite a marca do notebook");
            //n.marca = Console.ReadLine();
            //Console.WriteLine("Marca");
            //n.modelo = Console.ReadLine();
            //Console.WriteLine("Modelo");
            //n.tipo = Console.ReadLine();
            //Console.WriteLine("Preco");
            //n.preco = int.Parse(Console.ReadLine());


            //n.exibeDados();

            //n2 = new Notebook("Snow","Focus","AA", 56);
            //n2.exibeDados();



            //Console.WriteLine("Qual construtor você gostaria de utilizar? (1 - Nome e idade / 2 - Apenas idade)");
            //int opcao = int.Parse(Console.ReadLine());

            //if (opcao == 1)
            //{
            //    Console.WriteLine("Informe o nome:");
            //    string nome = Console.ReadLine();

            //    Console.WriteLine("Informe a idade:");
            //    int idade = int.Parse(Console.ReadLine());

            //    Pessoa2 pessoa = new Pessoa2(nome, idade);
            //}
            //else if (opcao == 2)
            //{
            //    Console.WriteLine("Informe a idade:");
            //    int idade = int.Parse(Console.ReadLine());

            //    Pessoa2 pessoa = new Pessoa2(idade);
            //}
            //else
            //{
            //    Console.WriteLine("Opção inválida!");
            //}

            //Console.ReadLine();

            //Aluno aluno1 = new Aluno("João", "12345"); // utilizando o primeiro construtor
            //Aluno aluno2 = new Aluno(new DateTime(2000, 5, 12)); // utilizando o segundo construtor
            //Aluno aluno3 = new Aluno("Maria", new DateTime(1999, 8, 7), 2021); // utilizando o terceiro construtor

            //Console.ReadLine();
        }
    }
}