﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ConsoleAppAula16
{
    internal class Carro
    {

        //public String marca, modelo;
        //public int ano;

        //public Carro()
        //{

        //}


        ////public Carro(String marca, string modelo, int ano)
        ////{
        ////    this.marca = marca;
        ////    this.modelo = modelo;
        ////    this.ano = ano;
        ////}


        //public void exibeDados()
        //{
        //    Console.WriteLine("Marca " + this.marca);
        //    Console.WriteLine("Modelo " + this.modelo);
        //    Console.WriteLine("Ano " + this.ano);
        //}

        //public void defineDados(String? mar, string? mod, int ano)
        //{
        //    this.marca = mar;
        //    this.modelo = mod;
        //    this.ano = ano;

        //}
    }
}
