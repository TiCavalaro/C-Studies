﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ConsoleAppAula23._1
{
    internal class IMotor
    {

        void Ligar();
        void Desligar();
    }
}
