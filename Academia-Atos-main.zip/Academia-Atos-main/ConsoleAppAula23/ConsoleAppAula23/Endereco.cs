﻿namespace Aula1505
{
    public class Endereco
    {
        public string Rua;
        public string Cep;
        public int Numero;

        public Endereco(string rua, string cep, int numero)
        {
            Rua = rua;
            Cep = cep;
            Numero = numero;
        }
    }
}