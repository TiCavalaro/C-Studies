﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ConsoleAppAula20
{
    internal class Carro
    {
        //private string marca;
        //private string modelo;
        //private int ano;
        //private Motor m;


        //public string Marca
        //{
        //    get
        //    {
        //        return marca;
        //    }
        //    set
        //    {
        //        marca = value;
        //    }
        //}

        //public string Modelo
        //{
        //    get
        //    {
        //        return modelo;

        //    }
        //    set
        //    {
        //        modelo = value;

        //    }
        //}

        //public int Ano
        //{
        //    get
        //    {
        //        return ano;
        //    }
        //    set
        //    {
        //        if (value > 0)
        //        {
        //            ano = value;

        //        }
        //    }
        //}

        //public Motor motor
        //{
        //    get { return m;  }
        //    set { m = value; }
        //}

        //public void LigarCarro()
        //{
        //    if(!m.Ligado)//(m.Ligado==false)
        //    {
        //        m.LigarMoto();
        //        Console.WriteLine("O carro ligou.");

        //    }
        //    else
        //    {
        //        Console.WriteLine("O carro esta ligado");
        //    }


        //}

        //public void DesligarCarro()
        //{
        //    if(m.Ligado)
        //    {
        //        m.DesligarMotor();
        //        Console.WriteLine("O carro desligou");
        //    }
        //    else
        //    {
        //        Console.WriteLine("O carro esta desligado");
        //    }
        //}
    }
}
