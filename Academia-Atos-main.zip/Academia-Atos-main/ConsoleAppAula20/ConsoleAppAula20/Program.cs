﻿namespace ConsoleAppAula20
{
    internal class Program
    {
        static void Main(string[] args)
        {

            //int idade;
            //string nome;

            //Console.WriteLine("Digite o nome e idade: ");
            //nome = Console.ReadLine();
            //idade = int.Parse(Console.ReadLine());
            //p = new Pessoa();
            //p.nome = "Astolfo";
            //Console.WriteLine("Nome: " + p.nome);


            //Pessoa p;
            //p = new Pessoa();
            //string nomeRetornado;
            //nomeRetornado = p.Nome;
            //Console.WriteLine("Digite o nome");
            //String nome = Console.ReadLine();
            //p.Nome = nome;

            //string nomeRetornado;
            //nomeRetornado = p.Nome;

            //Console.WriteLine("Nome :" + nomeRetornado);

            //Carro c = new Carro();
            //c.Marca = "VW";
            //c.Ano = 1999;
            //c.Modelo = "Gol";
            //c.Motor = new Motor();
            //c.Motor.Cilindradas = 1500;
            ////c.Motor.Ligado = 1000;            while (true)
            //{
            //    Console.WriteLine("Digite 1 para ligar e 2 para desligar: ");
            //    int op = int.Parse(Console.ReadLine());
            //    if (op == 1)
            //    {
            //        c.LigarCarro();
            //    }
            //    else if (op == 2)
            //    {
            //        c.DesligarCarro();
            //    }
            //    else if (op == 0)
            //    {
            //        break;
            //    }
            //}



            //Console.WriteLine("Digite 1 para criar Pessoa com nome e idade");
            //Console.WriteLine("Digite 2 para criar Pessoa com apenas a idade");
            //int opcao = int.Parse(Console.ReadLine());

            //if (opcao == 1)
            //{
            //    Console.WriteLine("Digite o nome da pessoa:");
            //    string nome = Console.ReadLine();

            //    Console.WriteLine("Digite a idade da pessoa:");
            //    int idade = int.Parse(Console.ReadLine());

            //    Pessoa pessoa1 = new Pessoa(nome, idade);
            //}
            //else if (opcao == 2)
            //{
            //    Console.WriteLine("Digite a idade da pessoa:");
            //    int idade = int.Parse(Console.ReadLine());

            //    Pessoa pessoa2 = new Pessoa(idade);
            //}
            //else
            //{
            //    Console.WriteLine("Opção inválida!");
            //}




            //Aluno aluno1 = new Aluno("João", 12345);
            //Aluno aluno2 = new Aluno("02/09/2002");
            //Aluno aluno3 = new Aluno("Maria","02/09/2002", 2021);

            //aluno1.ImprimirInformacoes();
            //Console.WriteLine();
            //aluno2.ImprimirInformacoes();
            //Console.WriteLine();
            //aluno3.ImprimirInformacoes();






            //ContaCorrente conta = new ContaCorrente();

            //Console.WriteLine("Digite o saldo inicial da conta:");
            //double saldoInicial = double.Parse(Console.ReadLine());
            //conta.DefinirSaldoInicial(saldoInicial);

            //Console.WriteLine("Deseja realizar um depósito? (S/N)");
            //string resposta = Console.ReadLine().ToUpper();
            //if (resposta == "S")
            //{
            //    Console.WriteLine("Digite o valor do depósito:");
            //    double valor = double.Parse(Console.ReadLine());
            //    conta.Depositar(valor);
            //}

            //Console.WriteLine("Deseja realizar um saque? (S/N)");
            //resposta = Console.ReadLine().ToUpper();
            //if (resposta == "S")
            //{
            //    Console.WriteLine("Digite o valor do saque:");
            //    double valor = double.Parse(Console.ReadLine());
            //    if (conta.Sacar(valor))
            //    {
            //        Console.WriteLine("Saque realizado com sucesso!");
            //    }
            //    else
            //    {
            //        Console.WriteLine("Saldo insuficiente para realizar o saque!");
            //    }
            //}

            //Console.WriteLine("Saldo atual: " + conta.Saldo);




            //Console.Write("Digite o número da conta: ");
            //int numero = int.Parse(Console.ReadLine());

            //Console.Write("Digite o saldo inicial: ");
            //double saldoInicial = double.Parse(Console.ReadLine());

            //Conta conta = new Conta(numero);
            //conta.DefinirSaldoInicial(saldoInicial);

            //Console.Write("Digite o limite da conta: ");
            //double limite = double.Parse(Console.ReadLine());
            //conta.Limite = limite;

            //Console.Write("Digite o valor a ser depositado: ");
            //double valor = double.Parse(Console.ReadLine());
            //conta.Depositar(valor);

            //Console.Write("Digite o valor a ser sacado: ");
            //valor = double.Parse(Console.ReadLine());
            //if (conta.Sacar(valor))
            //{
            //    Console.WriteLine("Saque realizado com sucesso!");
            //}
            //else
            //{
            //    Console.WriteLine("Saldo insuficiente para realizar o saque!");
            //}

            //Console.WriteLine("Número da conta: " + conta.Numero);
            //Console.WriteLine("Saldo atual: " + conta.Saldo);
            //Console.WriteLine("Limite da conta: " + conta.Limite);

        }
    }
}