﻿namespace ConsoleAppAula02
{
    internal class Program
    {
        static void Main(string[] args)
        {
            //Console.WriteLine("Hello, World!");
            //Console.WriteLine(2 + 2);

            //String nome= "Cavalaro";
            //Console.WriteLine("Digite seu nome");  
            // nome = Console.ReadLine();

            //Console.WriteLine("Seu nome e " + nome); //se valor nao atribuido, diferente de c++, o codigo nao acontece
            //string s; //texto
            //char x; //caractere
            //int z; //numeros inteiros
            //long l; //numeros inteiros
            //float y; //numeros reais
            //double d; //numeros reais
            //bool f; //logico


            //int idade = 32;
            //int dinheiro = 31;
            //int soma;
            //soma = idade + dinheiro;
            //Console.WriteLine("Sua idade e de " + (idade + dinheiro)+ " anos" + soma);

            //float k, j;
            //k = 1;
            //j = 2;
            //Console.WriteLine(k - j);
            //Console.WriteLine(k * j);
            //Console.WriteLine((double)k / (double)j);  //cast  
            //Console.WriteLine("A divisao entre " + k + " e " +  j + " resulta em " + k/j);
            //double a, b;//define a mudanca depois
            //double div = (double)a / (double)b;
            //double div = Convert.ToDouble(a) / Convert.ToDouble(b);

            //String nome;
            //double a, b,c,d;
            //Console.WriteLine("Digite seu nome");
            //nome = Console.ReadLine();
            //Console.Write("Digite o primeiro numero ");
            //a = double.Parse(Console.ReadLine());

            //Console.Write("Digite o segundo numero ");
            //b = double.Parse(Console.ReadLine());

            //Console.Write("Digite o terceiro numero ");
            //c = double.Parse(Console.ReadLine());

            //Console.Write("Digite o qaurtto numero ");
            //d = double.Parse(Console.ReadLine());

            //Console.WriteLine("ola " + nome +  "a  media aritmetica simples foi:  " + (a + b + c + d)/4);
            //Console.Write("Digite os graus em C para descobrir em F ");
            //double c,f;
            //c = double.Parse(Console.ReadLine());
            //f = 1.8 * c + 32;
            //Console.WriteLine("De C para F seria: " + f);

            //double a, b, c;
            //Console.Write("Digite o primeiro numero ");
            //a = double.Parse(Console.ReadLine());

            //Console.Write("Digite o segundo numero ");
            //b = double.Parse(Console.ReadLine());

            //Console.WriteLine("Os valores digitados em ordem foram: " + a + " e " + b);

            //c = a;
            //a = b;
            //b = c;

            //Console.WriteLine("Os valores digitados invertidos foram " + a + " e " + b);

            //Console.Write("Digite a data no formato DD/MM/AAAA: ");
            //string data = Console.ReadLine();


            //string dia = data.Substring(0, 2);
            //string mes = data.Substring(3, 2);
            //string ano = data.Substring(6, 4);


            //Console.WriteLine($"Data no formato AAAAMMDD:" +ano+ "/" + mes + "/" + dia);


            //Console.WriteLine($"Data no formato AAMMDD:"+ ano.Substring(2)+ "/" + mes+ "/"+dia);

            //Console.ReadKey();


            //Console.Write("Digite a distância percorrida total (em km): ");
            //double d = double.Parse(Console.ReadLine());

            //Console.Write("Digite o volume de combustível consumido: ");
            //double v = double.Parse(Console.ReadLine());

            //double consumo = d / v;

            //Console.WriteLine($"O consumo médio do automóvel é de {consumo} km/l.");

            //Console.ReadKey();


            //Console.WriteLine("Digite os dados do parafuso A:");
            //Console.Write("Codigo: ");
            //string cdA = Console.ReadLine();

            //Console.Write("Quantidade: ");
            //int qtA = int.Parse(Console.ReadLine());

            //Console.Write("Valor unitário: R$");
            //double vA = double.Parse(Console.ReadLine());

            // Leitura dos dados do parafuso B
            //Console.WriteLine("\nDados do parafuso B:");
            //Console.Write("Código: ");
            //string cdB = Console.ReadLine();

            //Console.Write("Quantidade de peças: ");
            //int qtB = int.Parse(Console.ReadLine());

            //Console.Write("Valor unitário: R$");
            //double vB = double.Parse(Console.ReadLine());

            // Leitura da porcentagem de IPI
            //Console.WriteLine("\nPorcentagem de IPI a ser acrescentada:");
            //double porcentagemIPI = double.Parse(Console.ReadLine());

            // Cálculo dos valores totais dos parafusos
            //double valorTotalA = qtA * vA;
            //double valorTotalB = qtB * vB;

            // Cálculo dos valores com o acréscimo de IPI
            //double valorComIPIA = valorTotalA * (1 + porcentagemIPI / 100);
            //double valorComIPIB = valorTotalB * (1 + porcentagemIPI / 100);

            // Impressão dos resultados
            //Console.WriteLine($"\nValor total do parafuso A (sem IPI): " + valorTotalA);
            //Console.WriteLine($"Valor total do parafuso B (sem IPI): " + valorTotalB);
            //Console.WriteLine($"Valor total do parafuso A (com IPI): " + valorComIPIA);
            //Console.WriteLine($"Valor total do parafuso B (com IPI): " + valorComIPIB);

            //Console.ReadKey();
            //int num;
            //double sal, total, perc, salarioTl;

            //Console.Write("Digite o número do vendedor: ");
            //num = int.Parse(Console.ReadLine());

            //Console.Write("Digite o salário fixo: R$ ");
            //sal = double.Parse(Console.ReadLine());

            ////Console.Write("Digite o total de vendas: R$ ");
            //total = double.Parse(Console.ReadLine());

            //Console.Write("Digite a comissão sobre as vendas (em %): ");
            //perc = double.Parse(Console.ReadLine());

            //salarioTl = sal + (total * perc / 100);

            //Console.WriteLine("O salário total do vendedor " + num + " é R$ " + salarioTl.ToString());


            //double valor, entrada, prestacao;

            //Console.Write("Digite o valor da mercadoria: R$ ");
            //valor = double.Parse(Console.ReadLine());

            //entrada = Math.Ceiling(valor * 0.6); 
            //prestacao = Math.Ceiling((valor - entrada) / 2); 

            //Console.WriteLine("Valor da entrada: R$ " + entrada.ToString());
            //Console.WriteLine("Valor das duas prestações: R$ " + prestacao.ToString());
            //int valor, n50, n20, n10, n5, n2, n1;

            //Console.Write("Digite o valor da quantia solicitada: R$ ");
            //valor = int.Parse(Console.ReadLine());

            // n50 = valor / 50;
            //valor %= 50;

            //n20 = valor / 20;
            //valor %= 20;

            //n10 = valor / 10;
            //valor %= 10;

            //n5 = valor / 5;
            //valor %= 5;

            //n2 = valor / 2;
            //valor %= 2;

            //n1 = valor;

            //Console.WriteLine("Notas de R$ 50,00: " + n50);
            //Console.WriteLine("Notas de R$ 20,00: " + n20);
            //Console.WriteLine("Notas de R$ 10,00: " + n10);
            //Console.WriteLine("Notas de R$ 5,00: " + n5);
            //Console.WriteLine("Notas de R$ 2,00: " + n2);
            //Console.WriteLine("Notas de R$ 1,00: " + n1);
            // double Combu = 6.9;

            //Console.WriteLine("Informe a marcação no início do dia (em Km):");
            //double inicio = double.Parse(Console.ReadLine());

            //Console.WriteLine("Informe a marcação no final do dia (em Km):");
            //double final = double.Parse(Console.ReadLine());

            //Console.WriteLine("Informe o número de litros de combustível gasto no dia:");
            //double litros = double.Parse(Console.ReadLine());

            //Console.WriteLine("Informe o valor total recebido dos passageiros (R$):");
            //double total = double.Parse(Console.ReadLine());

            //double totalKm = final - inicio;
            //double media = totalKm / litros;
            //double lucro = total - litros * Combu;

            //Console.WriteLine("Média de consumo: " + media.ToString() + " Km/l");
            //Console.WriteLine("Lucro líquido: R$ " + lucro.ToString());
            //double elei, brancos, nulo, validos;

            //Console.Write("Digite o número de eleitores: ");
            //elei = double.Parse(Console.ReadLine());

            //Console.Write("Digite o número de votos brancos: ");
            //brancos = double.Parse(Console.ReadLine());

            //Console.Write("Digite o número de votos nulos: ");
            //nulo = double.Parse(Console.ReadLine());

            //Console.Write("Digite o número de votos válidos: ");
            //validos = double.Parse(Console.ReadLine());

            //double percBrancos = (brancos / elei) * 100;
            //double percNulos = (nulo / elei) * 100;
            //double percValidos = (validos / elei) * 100;

            //Console.WriteLine($"Percentual de votos brancos: {percBrancos}%");
            //Console.WriteLine($"Percentual de votos nulos: {percNulos}%");
            //Console.WriteLine($"Percentual de votos válidos: {percValidos}%");

            //double minimo, custo, salario, comissao, final;
            //int numBicicletas;

            //Console.Write("Digite o valor do salário mínimo: R$ ");
            //minimo = double.Parse(Console.ReadLine());

            //Console.Write("Digite o preço de custo de cada bicicleta: R$ ");
            //custo = double.Parse(Console.ReadLine());
            //Console.Write("Digite o número de bicicletas vendidas pelo vendedor: ");
            //numBicicletas = int.Parse(Console.ReadLine());

            //custo = custo * 1.5;
            //salario = 2 * minimo;
            // comissao = 0.15 * custo * numBicicletas;
            // final = salario + comissao;

            // Console.WriteLine("O salário do empregado é: R$" + final);
            //int i;

            //Console.WriteLine("Digite um numero");
            //i = int.Parse(Console.ReadLine());

            //if(i%2==0) 
            //{
            //    Console.WriteLine("Divisivel por 2");
            //    if (i % 4 == 0)
            //    {
            //        Console.WriteLine("Divisivel por 4");
            //        if(i % 8 == 0)
            //        {
            //            Console.WriteLine("Divisivel por 8");

            //        }
            //    }

            //}
            //ctrlz k c
            //int i;
            //Console.WriteLine("Digite sua idade");
            //i = int.Parse(Console.ReadLine());

            //if(i>=18)
            //{
            //    Console.WriteLine("Voce e maior de idade");
            //}else
            //{
            //    Console.WriteLine("Voce e menor de idade");
            //}
            //    double num1, num2, result;
            //    char oper;

            //    Console.Write("Numero 1: ");
            //    num1 = double.Parse(Console.ReadLine());

            //    Console.Write("Numero 2: ");
            //    num2 = double.Parse(Console.ReadLine());

            //    Console.Write("Enter operation (+, -, *, /): ");
            //    oper = char.Parse(Console.ReadLine());

            //    switch (oper)
            //    {
            //        case '+':
            //            result = num1 + num2;
            //            Console.WriteLine("Resultado: " + result);
            //            break;
            //        case '-':
            //            result = num1 - num2;
            //            Console.WriteLine("Resultado: " + result);
            //            break;
            //        case '*':
            //            result = num1 * num2;
            //            Console.WriteLine("Resultado: " + result);
            //            break;
            //        case '/':
            //            if (num2 == 0)
            //            {
            //                Console.WriteLine("Nao se pode dividir por 0");
            //            }
            //            else
            //            {
            //                result = num1 / num2;
            //                Console.WriteLine("Resultado: " + result);
            //            }
            //            break;
            //        default:
            //            Console.WriteLine("Opercao invalida");
            //            break;
            //    }

            //}
        }
    }
}
    
