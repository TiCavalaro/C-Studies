DDL
create
alter
drop

CREATE DATABASE AulaAtos;
DROP DATABASE AulaAtos


DML
insert
update
delete


CRUD
