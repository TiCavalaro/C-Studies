// var teste = "Hello World";
// alert(teste)
    
            // alert('pagina carregando...');
            // var variavel = "valor";
            // var texto = 'valor';
            // var n1 = 50;
            // var n2 = 5.9;
            // var booleano = true;

            // var u = undefined;
            // var n = null;

            // var obj =
            // {
            //     id:1,
            //     nome:"Fabricio"
            // };

            // var arrays = ["Fabricio","Toneto","lenador"];

            // var func = function(x,y){
            //     return x+y;
            // };

            // var retorno = func(5,4);
            // alert(retorno);

            // var valor = 2;
            // if(valor =="2"){
            //     alert("deu verdadeiro"); //analisa os valores das variaveis
            // }

            // if(valor === "2"){
            //     alert("deu verdadeir");//analisa os valores e tipos das variaveis, ta fazendo por texto
            // }
            // else{
            //     alert("deu falso");
            // }

            // var retorno = (valor === "2")?"verdadeiro":"falso";
            // alert(retorno);

            // var alunos = ["Lucas", "Apellidos", "Novembedos"];
            // for(var i = 0; i < alunos.length; i++) {
            //     alert(alunos[i]);
            // }

            // var nomeCompleto = "";
            // var professor = 
            // {
            //     nome:   "Novembedos",
            //     sobrenome: "Sobrenome"

            // };

            // for (p in professor) {
            //     nomeCompleto += professor[p];+" ";

            // }
            // alert(nomeCompleto)


            // var num1 = "2";
            // var num2 = "3";

            // alert(num1 + num2);

                // for (let i = 1; i <= 10; i++) {
                //     if (i % 2 !== 0) {
                //         alert(i);
                //     }
                // }
                //     var x=0;
                // for (let i = 1; i <= 100; i++) {
                //     x = x+i;
                    
                // }
                // alert(x);

                // var clicks = 0;
            //     <!-- var tags = document.getElementsByTagName("div");
            //     var classes = document.getElementsByClassName("divs");
            //     var unico = document.getElementById("div1");

            // console.log(tags);
            // console.log(classes);
            // console.log(unico); -->