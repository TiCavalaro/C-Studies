﻿namespace ConsoleAppAula05
{
    internal class Program
    {
        static void Main(string[] args)
        {

            //int i;
            //for (i = 0; i < 4; i++)
            //{
            //    Console.WriteLine(i);
            //}

            //int i;
            //for (i = 0; i < 11; i++)
            //{
            //    Console.WriteLine(i);
            //}


            //int i;
            //for (i = 20; i >= 5; i--)
            //{
            //    Console.WriteLine(i);
            //}

            //int inicio, fim;
            //Console.WriteLine("Digite o numero inicial");
            //inicio = int.Parse(Console.ReadLine());  
            //Console.WriteLine("Digite o numero final");
            //fim = int.Parse(Console.ReadLine());


            //int i;
            //for (i = inicio; i < fim+1; i++)
            //{
            //    Console.WriteLine(i);
            //}

            //int pula;
            //Console.WriteLine("Digite o numero inicial");
            //pula = int.Parse(Console.ReadLine());

            //int i;
            //for (i = 0; i < 101; i=i+pula)
            //{
            //    Console.WriteLine(i);
            //}



            //int i,x;

            //Console.WriteLine("Digite o numero inicial");
            //x = int.Parse(Console.ReadLine());
            //for (i = 0; i < 101; i++)
            //{

            //    if (i % x == 0)
            //    {
            //        Console.WriteLine(i);
            //    }
            //}

            //int n;
            //double soma = 0;

            //Console.Write("Digite o número de pessoas: ");
            //n = int.Parse(Console.ReadLine());

            //for (int i = 1; i <= n; i++)
            //{
            //    Console.Write($"Digite a idade da pessoa " + i);
            //    int idade = int.Parse(Console.ReadLine());
            //    soma += idade;
            //}

            //double media = soma / n;
            //Console.WriteLine($"A média de idade das " + n + "  pessoas é: " + media );

            //int maior=0;

            //for (int i = 1; i <= 10; i++)
            //{
            //    Console.Write($"Digite o " + i + " número: ");
            //    int num = int.Parse(Console.ReadLine());

            //    if (num > maior)
            //    {
            //        maior = num;
            //    }
            //}

            //Console.WriteLine($"O maior número é: " + maior);

            //Console.Write("Digite um número: ");
            //int x = int.Parse(Console.ReadLine());

            // for (int i = 1; i <= 10; i++) {
            //     int resultado = x * i;
            //    Console.WriteLine(x + "x" + i + " = " + resultado);
            // }

            //Console.Write("Digite o valor de x: ");
            //int x = int.Parse(Console.ReadLine());

            //Console.Write("Digite o valor de y: ");
            //int y = int.Parse(Console.ReadLine());

            //int potencia = 1;
            //for (int i = 1; i <= y; i++)
            //{
            //    potencia *= x;
            //}

            //Console.WriteLine(x + " elevado a " + y + " = " + potencia);

            //Console.Write("Digite um número: ");
            //int num = int.Parse(Console.ReadLine());

            //int fatorial = 1;
            //for (int i = num; i >= 1; i--)
            //{
            //    fatorial *= i;
            //}

            //Console.WriteLine("O fatorial de " + num +  " é " + fatorial);

            //Console.Write("Digite o número de alunos ");
            //int alunos = int.Parse(Console.ReadLine());

            //Console.Write("Digite a quantidade de avaliações");
            //int numAvaliacoes = int.Parse(Console.ReadLine());

            //for (int i = 1; i <= alunos; i++)
            //{
            //    double somaNotas = 0;
            //    for (int j = 1; j <= numAvaliacoes; j++)
            //    {
            //        Console.Write($"Digite a nota da avaliação " + j + " do aluno  " + i);
            //        double nota = double.Parse(Console.ReadLine());
            //        somaNotas += nota;
            //    }
            //    double media = somaNotas / numAvaliacoes;
            //    Console.WriteLine($"A nota final do aluno {i} é {media}");

            //}

            //int numpares = 0;
            //int numImp = 0;

            //for (int i = 1; i <= 20; i++)
            //{
            //    Console.Write($"Digite o "  + i + " número: ");
            //    int num = int.Parse(Console.ReadLine());

            //    if (num % 2 == 0)
            //    {
            //        numpares++;
            //    }
            //    else
            //    {
            //        numImp++;
            //    }
            //}

            //Console.WriteLine($"Foram digitados " + numpares + " números pares e " + numImp + " números ímpares.");
        }
    }
}
    }
}
